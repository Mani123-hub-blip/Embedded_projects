#ifndef GSM_NETWORK_H
#define GSM_NETWORK_H

#include <Arduino.h>
#include "app_state.h"

void initGsmAndWifi();
void serviceNetworkAndOta();
void requestRouteSync();
void requestOtaCheck();
void forgetSavedWifiCredentials();
#endif // GSM_NETWORK_H
