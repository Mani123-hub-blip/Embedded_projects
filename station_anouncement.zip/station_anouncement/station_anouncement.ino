#include <Arduino.h>
#include <SPI.h>
#include <SD.h>
#include "app_state.h"
#include "display_ui.h"
#include "audio_player.h"
#include "gps_manager.h"
#include "battery_monitor.h"
#include "gsm_network.h"

SystemTelemetry sysState;
SemaphoreHandle_t stateMutex = NULL;
SemaphoreHandle_t spiBusMutex = NULL;

// Core 0 Task: Wi-Fi, EG800Q-IN 4G, Route Sync, Audio Downloader, & OTA Engine
void networkWorkerTask(void *pvParameters) {
  initGsmAndWifi();

  for (;;) {
    serviceNetworkAndOta();
    vTaskDelay(pdMS_TO_TICKS(50));
  }
}

void setup() {
  Serial.begin(115200);
  delay(200);
  Serial.println("\n=== MINDCOIN STATION ANNOUNCEMENT SYSTEM v" FW_VERSION " ===");

  stateMutex = xSemaphoreCreateMutex();
  spiBusMutex = xSemaphoreCreateMutex();

  // Deselect both SPI devices before initializing bus
  pinMode(PIN_LCD_CS, OUTPUT);
  digitalWrite(PIN_LCD_CS, HIGH);
  pinMode(PIN_SD_CS, OUTPUT);
  digitalWrite(PIN_SD_CS, HIGH);

  SPI.begin(PIN_SPI_SCLK, PIN_SPI_MISO, PIN_SPI_MOSI);

  if (xSemaphoreTake(spiBusMutex, pdMS_TO_TICKS(200)) == pdTRUE) {
    if (!SD.begin(PIN_SD_CS, SPI, 20000000)) {
      Serial.println("[SD] Card mount failed or missing!");
    } else {
      Serial.printf("[SD] Card mounted (%llu MB)\n", SD.cardSize() / (1024ULL * 1024ULL));
    }
    xSemaphoreGive(spiBusMutex);
  }

  initBatteryMonitor();
  initAudioPlayer();
  initGPSManager();
  initDisplayAndLVGL();
  buildSplashScreen();

  // Pin network/HTTP/OTA tasks to Core 0 so Core 1 stays dedicated to LVGL + I2S Audio
  xTaskCreatePinnedToCore(
    networkWorkerTask,
    "NetWorkerTask",
    12288,
    NULL,
    1,
    NULL,
    0
  );
}

void loop() {
  lv_timer_handler();
  serviceGPSManager();
  serviceBatteryMonitor();
  serviceAudioPlayback();
  updateUIDashboard();
  delay(5);
}
