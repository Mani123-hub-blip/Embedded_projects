#ifndef APP_STATE_H
#define APP_STATE_H

#include <Arduino.h>
#include <freertos/FreeRTOS.h>
#include <freertos/semphr.h>

// Device & Firmware Metadata
#define DEVICE_MODEL        "MINDCOIN-SAS-S3"
#define FW_VERSION          "4.1.0"
#define OTA_ADMIN_PASSWORD  "1234"
#define CELLULAR_APN        "airtelgprs.com"

// Display & Shared SPI Bus (ST7796S + SD Card)
#define SCREEN_WIDTH        480
#define SCREEN_HEIGHT       320
#define TFT_ROTATION        1
#define PIN_SPI_MOSI        11
#define PIN_SPI_MISO        13
#define PIN_SPI_SCLK        12
#define PIN_LCD_CS          10
#define PIN_LCD_DC          1
#define PIN_LCD_RST         39
#define PIN_LCD_BL          21
#define PIN_SD_CS           7

// Capacitive Touch I2C (Wire - FT6336U)
#define PIN_TOUCH_SDA       8
#define PIN_TOUCH_SCL       9
#define PIN_TOUCH_INT       2

// Battery Fuel Gauge I2C (Wire1 - MAX17048, isolated from touch bus)
#define PIN_BAT_SDA         41
#define PIN_BAT_SCL         40

// MAX98357A I2S Audio (GPIO 38 avoids N16R8 OPI PSRAM on GPIO 35-37 / 14)
#define PIN_I2S_BCLK        38
#define PIN_I2S_LRCLK       15
#define PIN_I2S_DIN         16
#define PIN_I2S_SD_MODE     6

// Quectel L89H GNSS (UART1) & EG800Q-IN 4G Modem (UART2)
#define PIN_GPS_TX          4
#define PIN_GPS_RX          5
#define PIN_GSM_TX          17
#define PIN_GSM_RX          18

// Backend Endpoints (Configure for your deployment server)
#define API_BASE_URL        "http://api.mindcoin-rail.local:8000"
#define ROUTE_SYNC_URL      API_BASE_URL "/api/v1/routes/active"
#define OTA_MANIFEST_URL    API_BASE_URL "/api/v1/ota/manifest"

struct WifiNetworkInfo {
  char ssid[33];
  int32_t rssi;
  bool is_open;
};

struct SystemTelemetry {
  // Time & GNSS
  char utc_time[16] = "--:--:--";
  double latitude = 17.4399;
  double longitude = 78.4983;
  float speed_kmh = 0.0f;
  uint8_t satellites = 0;
  float hdop = 99.9f;
  bool gps_valid = false;

  // Station & Announcement State
  char current_station[48] = "SECUNDERABAD JN";
  char next_station[48] = "BEGUMPET";
  float dist_to_next_m = 4200.0f;
  char current_audio_file[64] = "/announce_current.wav";

  // Battery (MAX17048)
  uint8_t battery_percent = 92;
  float battery_voltage = 4.12f;
  bool is_charging = false;

  // Connectivity (Wi-Fi & EG800Q-IN 4G)
  uint8_t gsm_bars = 0;
  bool gsm_registered = false;
  bool wifi_enabled = true;
  bool wifi_connected = false;
  bool wifi_connecting = false;
  char wifi_ssid[33] = "";
  char target_wifi_ssid[33] = "";
  char target_wifi_pass[65] = "";
  bool wifi_connect_requested = false;
  bool wifi_scan_requested = false;
  bool wifi_scan_in_progress = false;
  bool wifi_scan_ready = false;
  uint8_t wifi_found_count = 0;
  WifiNetworkInfo wifi_list[12];

  // User Settings
  uint8_t brightness_percent = 85;
  uint8_t volume_percent = 80;

  // OTA Update & Numeric PIN Authorization
  bool ota_active = false;
  uint8_t ota_progress = 0;
  char ota_status_text[64] = "Preparing OTA update...";
  bool ota_auth_required = false;
  bool ota_auth_approved = false;
  bool ota_auth_cancelled = false;
  char pending_ota_url[160] = "";
};

extern SystemTelemetry sysState;
extern SemaphoreHandle_t stateMutex;
extern SemaphoreHandle_t spiBusMutex;

#endif // APP_STATE_H
