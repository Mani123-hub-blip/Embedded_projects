#include "gps_manager.h"
#include "audio_player.h"
#include <math.h>

static HardwareSerial gpsSerial(1);
static char nmeaLine[128];
static uint8_t nmeaIdx = 0;

static double targetNextLat = 17.4435;
static double targetNextLon = 78.4608;
static bool geofenceTriggered = false;

static double nmeaCoordToDecimal(const char *val, char hemi) {
  if (!val || val[0] == '\0') return 0.0;
  double raw = atof(val);
  int deg = (int)(raw / 100.0);
  double min = raw - (deg * 100.0);
  double dec = deg + (min / 60.0);
  if (hemi == 'S' || hemi == 'W') dec = -dec;
  return dec;
}

static float haversineMeters(double lat1, double lon1, double lat2, double lon2) {
  const double R = 6371000.0;
  double dLat = radians(lat2 - lat1);
  double dLon = radians(lon2 - lon1);
  double a = sin(dLat / 2) * sin(dLat / 2) +
             cos(radians(lat1)) * cos(radians(lat2)) *
             sin(dLon / 2) * sin(dLon / 2);
  double c = 2 * atan2(sqrt(a), sqrt(1 - a));
  return (float)(R * c);
}

static void parseNmeaSentence(char *line) {
  if (strncmp(line, "$GNRMC", 6) == 0 || strncmp(line, "$GPRMC", 6) == 0) {
    char *tokens[13] = {0};
    int count = 0;
    char *p = strtok(line, ",");
    while (p && count < 13) {
      tokens[count++] = p;
      p = strtok(NULL, ",");
    }
    if (count >= 8 && tokens[2] && tokens[2][0] == 'A') {
      double lat = nmeaCoordToDecimal(tokens[3], tokens[4] ? tokens[4][0] : 'N');
      double lon = nmeaCoordToDecimal(tokens[5], tokens[6] ? tokens[6][0] : 'E');
      float spdKmh = tokens[7] ? (atof(tokens[7]) * 1.852f) : 0.0f;

      char utcFmt[16] = "--:--:--";
      if (tokens[1] && strlen(tokens[1]) >= 6) {
        snprintf(utcFmt, sizeof(utcFmt), "%.2s:%.2s:%.2s", tokens[1], tokens[1] + 2, tokens[1] + 4);
      }

      float distM = haversineMeters(lat, lon, targetNextLat, targetNextLon);
      char triggerAudio[64] = "";

      if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        sysState.gps_valid = true;
        sysState.latitude = lat;
        sysState.longitude = lon;
        sysState.speed_kmh = spdKmh;
        sysState.dist_to_next_m = distM;
        strncpy(sysState.utc_time, utcFmt, sizeof(sysState.utc_time) - 1);

        // Auto-announce within 500m approach geofence
        if (distM <= 500.0f && !geofenceTriggered) {
          geofenceTriggered = true;
          strncpy(triggerAudio, sysState.current_audio_file, sizeof(triggerAudio) - 1);
        }
        xSemaphoreGive(stateMutex);
      }

      if (triggerAudio[0] != '\0') {
        playStationAnnouncement(triggerAudio);
      }
    }
  } else if (strncmp(line, "$GNGGA", 6) == 0 || strncmp(line, "$GPGGA", 6) == 0) {
    char *tokens[10] = {0};
    int count = 0;
    char *p = strtok(line, ",");
    while (p && count < 10) {
      tokens[count++] = p;
      p = strtok(NULL, ",");
    }
    if (count >= 9) {
      uint8_t sats = tokens[7] ? (uint8_t)atoi(tokens[7]) : 0;
      float hdop = tokens[8] ? atof(tokens[8]) : 99.9f;
      if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        sysState.satellites = sats;
        sysState.hdop = hdop;
        xSemaphoreGive(stateMutex);
      }
    }
  }
}

void initGPSManager() {
  gpsSerial.begin(115200, SERIAL_8N1, PIN_GPS_RX, PIN_GPS_TX);
}

void serviceGPSManager() {
  while (gpsSerial.available()) {
    char c = (char)gpsSerial.read();
    if (c == '\n' || c == '\r') {
      if (nmeaIdx > 6) {
        nmeaLine[nmeaIdx] = '\0';
        parseNmeaSentence(nmeaLine);
      }
      nmeaIdx = 0;
    } else if (nmeaIdx < sizeof(nmeaLine) - 1) {
      nmeaLine[nmeaIdx++] = c;
    }
  }
}

void updateActiveStationList(const char *currName, const char *nextName, double nextLat, double nextLon, const char *audioPath) {
  targetNextLat = nextLat;
  targetNextLon = nextLon;
  geofenceTriggered = false;

  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
    strncpy(sysState.current_station, currName, sizeof(sysState.current_station) - 1);
    strncpy(sysState.next_station, nextName, sizeof(sysState.next_station) - 1);
    strncpy(sysState.current_audio_file, audioPath, sizeof(sysState.current_audio_file) - 1);
    xSemaphoreGive(stateMutex);
  }
}
