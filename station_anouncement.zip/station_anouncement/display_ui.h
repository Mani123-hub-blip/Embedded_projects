#ifndef DISPLAY_UI_H
#define DISPLAY_UI_H

#include <Arduino.h>
#include <lvgl.h>
#include <Arduino_GFX_Library.h>
#include <RAK14014_FT6336U.h>
#include <Preferences.h>
#include "app_state.h"

void initDisplayAndLVGL();
void buildSplashScreen();
void buildHomeScreen();
void buildGPSScreen();
void buildSettingsScreen();
void setBacklightBrightness(uint8_t percent);
void updateUIDashboard();

#endif // DISPLAY_UI_H
