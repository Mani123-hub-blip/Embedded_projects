#ifndef AUDIO_PLAYER_H
#define AUDIO_PLAYER_H

#include <Arduino.h>
#include "app_state.h"

void initAudioPlayer();
void playStationAnnouncement(const char *filePath);
void serviceAudioPlayback();
void setAudioVolume(uint8_t percent);

bool queueMissingAudioFile(const char *filePath);
bool popNextMissingAudioFile(char *outPath, size_t maxLen);

#endif // AUDIO_PLAYER_H
