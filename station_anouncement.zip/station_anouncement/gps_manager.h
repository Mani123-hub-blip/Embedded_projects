#ifndef GPS_MANAGER_H
#define GPS_MANAGER_H

#include <Arduino.h>
#include "app_state.h"

void initGPSManager();
void serviceGPSManager();
void updateActiveStationList(const char *currName, const char *nextName, double nextLat, double nextLon, const char *audioPath);

#endif // GPS_MANAGER_H
