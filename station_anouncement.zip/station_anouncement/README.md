# MINDCOIN Station Announcement System (ESP32-S3-WROOM-1 N16R8)

## Project Structure
Extract the `station_anouncement/` folder into your Arduino sketches directory (`E:\arduino projects\gemini projects\`) and open `station_anouncement.ino`.

- `station_anouncement.ino`: Main entry point, SPI bus / SD initialization, FreeRTOS Core 0 network worker task, and Core 1 UI/Audio/GNSS loop.
- `app_state.h`: Hardware pin mappings, server endpoints, `OTA_ADMIN_PASSWORD` (`"1234"`), `CELLULAR_APN`, and shared `SystemTelemetry` state.
- `display_ui.h` / `display_ui.cpp`: ST7796S SPI display + FT6336U capacitive touch + LVGL v9 interface, numeric PIN OTA authorization modal, Wi-Fi manager, and `spiBusMutex`-guarded flush.
- `audio_player.h` / `audio_player.cpp`: MAX98357A I2S playback (`ESP_I2S`), software volume scaling, `spiBusMutex`-guarded SD reads, and thread-safe missing-audio download queue.
- `gps_manager.h` / `gps_manager.cpp`: Quectel L89H R2.0 NMEA parser on UART1 and 500 m Haversine approach geofence trigger.
- `battery_monitor.h` / `battery_monitor.cpp`: MAX17048 fuel gauge driver on `Wire1` (GPIO 41/40).
- `gsm_network.h` / `gsm_network.cpp`: Wi-Fi + Quectel EG800Q-IN 4G HTTP fallback (`AT+QHTTPGET` / `AT+QHTTPREADFILE`), background audio downloader, and PIN-authorized OTA updater.

## Arduino IDE Board Settings (ESP32-S3 N16R8)
- **Board:** ESP32S3 Dev Module
- **Flash Size:** 16MB (128Mb)
- **Flash Mode:** QIO 80MHz
- **Partition Scheme:** 16M Flash (3MB APP/9.9MB FATFS) or Dual OTA 16MB
- **PSRAM:** OPI PSRAM
