#ifndef BATTERY_MONITOR_H
#define BATTERY_MONITOR_H

#include <Arduino.h>
#include "app_state.h"

void initBatteryMonitor();
void serviceBatteryMonitor();

#endif // BATTERY_MONITOR_H
