#include "gsm_network.h"
#include "audio_player.h"
#include "gps_manager.h"
#include <WiFi.h>
#include <HTTPClient.h>
#include <Update.h>
#include <SD.h>
#include <Preferences.h>

static HardwareSerial gsmSerial(2);
static Preferences wifiPrefs;

static volatile bool routeSyncRequested = false;
static volatile bool otaCheckRequested = false;
static bool gsmPdpReady = false;

void requestRouteSync() {
  routeSyncRequested = true;
}

void requestOtaCheck() {
  otaCheckRequested = true;
}

void forgetSavedWifiCredentials() {
  wifiPrefs.begin("wifi_cfg", false);
  wifiPrefs.clear();
  wifiPrefs.end();

  WiFi.disconnect(true, true);
  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
    sysState.wifi_connected = false;
    sysState.wifi_connecting = false;
    sysState.wifi_ssid[0] = '\0';
    xSemaphoreGive(stateMutex);
  }
}

// Send an AT command and wait until expected token or timeout
static bool sendAtWait(const char *cmd, const char *expect, uint32_t timeoutMs, String *outResp = nullptr) {
  while (gsmSerial.available()) gsmSerial.read();
  if (cmd && cmd[0] != '\0') {
    gsmSerial.println(cmd);
  }

  String acc;
  acc.reserve(256);
  uint32_t t0 = millis();
  while (millis() - t0 < timeoutMs) {
    while (gsmSerial.available()) {
      char c = (char)gsmSerial.read();
      acc += c;
    }
    if (expect && acc.indexOf(expect) >= 0) {
      if (outResp) *outResp = acc;
      return true;
    }
    if (acc.indexOf("\r\nERROR\r\n") >= 0 || acc.indexOf("+CME ERROR:") >= 0) {
      if (outResp) *outResp = acc;
      return false;
    }
    vTaskDelay(pdMS_TO_TICKS(10));
  }
  if (outResp) *outResp = acc;
  return false;
}

// Configure and activate PDP context 1 on EG800Q-IN
static bool ensureEg800qPdpActive() {
  if (!sysState.gsm_registered) {
    gsmPdpReady = false;
    return false;
  }

  String resp;
  if (sendAtWait("AT+QIACT?", "+QIACT: 1,1,", 1500, &resp)) {
    gsmPdpReady = true;
    return true;
  }

  char apnCmd[96];
  snprintf(apnCmd, sizeof(apnCmd), "AT+QICSGP=1,1,\"%s\",\"\",\"\",1", CELLULAR_APN);
  sendAtWait(apnCmd, "OK", 2000);

  if (sendAtWait("AT+QIACT=1", "OK", 15000)) {
    gsmPdpReady = true;
    Serial.println("[GSM] EG800Q-IN PDP context 1 activated.");
    return true;
  }

  gsmPdpReady = false;
  return false;
}

// Configure URL and trigger AT+QHTTPGET on EG800Q-IN; returns content length (>0) or -1 on error
static int eg800qStartHttpGet(const char *url) {
  if (!ensureEg800qPdpActive()) return -1;

  sendAtWait("AT+QHTTPCFG=\"contextid\",1", "OK", 1000);
  sendAtWait("AT+QHTTPCFG=\"responseheader\",0", "OK", 1000);
  if (strncmp(url, "https://", 8) == 0) {
    sendAtWait("AT+QHTTPCFG=\"sslctxid\",1", "OK", 1000);
    sendAtWait("AT+QSSLCFG=\"seclevel\",1,0", "OK", 1000);
    sendAtWait("AT+QSSLCFG=\"sni\",1,1", "OK", 1000);
  }

  size_t urlLen = strlen(url);
  char urlCmd[48];
  snprintf(urlCmd, sizeof(urlCmd), "AT+QHTTPURL=%u,30", (unsigned)urlLen);
  if (!sendAtWait(urlCmd, "CONNECT", 5000)) {
    return -1;
  }

  gsmSerial.print(url);
  if (!sendAtWait(nullptr, "OK", 5000)) {
    return -1;
  }

  String getResp;
  if (!sendAtWait("AT+QHTTPGET=60", "+QHTTPGET:", 65000, &getResp)) {
    return -1;
  }

  int p = getResp.indexOf("+QHTTPGET:");
  if (p < 0) return -1;
  String line = getResp.substring(p + 10);
  line.trim();

  int c1 = line.indexOf(',');
  int c2 = (c1 >= 0) ? line.indexOf(',', c1 + 1) : -1;
  int errCode = line.substring(0, c1).toInt();
  int httpStatus = (c1 >= 0) ? line.substring(c1 + 1, (c2 >= 0) ? c2 : line.length()).toInt() : 0;
  int contentLen = (c2 >= 0) ? line.substring(c2 + 1).toInt() : 0;

  if (errCode != 0 || httpStatus != 200) {
    Serial.printf("[GSM] QHTTPGET failed: err=%d status=%d\n", errCode, httpStatus);
    return -1;
  }
  return contentLen;
}

// Perform small JSON HTTP GET over EG800Q-IN (Route Sync / OTA Manifest)
static bool eg800qHttpGetToString(const char *url, String &outBody) {
  int len = eg800qStartHttpGet(url);
  if (len < 0) return false;

  String raw;
  if (!sendAtWait("AT+QHTTPREAD=30", "+QHTTPREAD: 0", 32000, &raw)) {
    return false;
  }

  int startIdx = raw.indexOf("CONNECT\r\n");
  int endIdx = raw.lastIndexOf("\r\nOK\r\n+QHTTPREAD: 0");
  if (startIdx >= 0 && endIdx > startIdx + 9) {
    outBody = raw.substring(startIdx + 9, endIdx);
    return true;
  }
  return false;
}

// Stream binary HTTP GET from EG800Q-IN UFS to either SD file or ESP32 OTA Update partition
static bool eg800qHttpDownloadBinary(const char *url, const char *sdDestPath, bool isOtaFirmware) {
  int totalLen = eg800qStartHttpGet(url);
  if (totalLen <= 0) return false;

  sendAtWait("AT+QFDEL=\"UFS:dl_tmp.bin\"", "OK", 1500);
  if (!sendAtWait("AT+QHTTPREADFILE=\"UFS:dl_tmp.bin\",60", "+QHTTPREADFILE: 0", 65000)) {
    Serial.println("[GSM] QHTTPREADFILE failed.");
    return false;
  }

  String openResp;
  if (!sendAtWait("AT+QFOPEN=\"UFS:dl_tmp.bin\",2", "+QFOPEN:", 3000, &openResp)) {
    return false;
  }
  int handleIdx = openResp.indexOf("+QFOPEN:");
  int fileHandle = openResp.substring(handleIdx + 8).toInt();

  File sdFile;
  if (isOtaFirmware) {
    if (!Update.begin((size_t)totalLen)) {
      char closeCmd[32];
      snprintf(closeCmd, sizeof(closeCmd), "AT+QFCLOSE=%d", fileHandle);
      sendAtWait(closeCmd, "OK", 1500);
      return false;
    }
  } else {
    bool opened = false;
    if (spiBusMutex != NULL && xSemaphoreTake(spiBusMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
      sdFile = SD.open(sdDestPath, FILE_WRITE);
      opened = (bool)sdFile;
      xSemaphoreGive(spiBusMutex);
    }
    if (!opened) return false;
  }

  uint8_t chunkBuf[512];
  size_t totalRead = 0;
  bool ok = true;

  while (totalRead < (size_t)totalLen) {
    size_t toRead = min((size_t)sizeof(chunkBuf), (size_t)totalLen - totalRead);
    char readCmd[48];
    snprintf(readCmd, sizeof(readCmd), "AT+QFREAD=%d,%u", fileHandle, (unsigned)toRead);

    while (gsmSerial.available()) gsmSerial.read();
    gsmSerial.println(readCmd);

    String hdr;
    uint32_t t0 = millis();
    int actualBytes = -1;
    while (millis() - t0 < 3000) {
      if (gsmSerial.available()) {
        char c = (char)gsmSerial.read();
        hdr += c;
        if (hdr.endsWith("\r\n")) {
          int cPos = hdr.indexOf("CONNECT ");
          if (cPos >= 0) {
            actualBytes = hdr.substring(cPos + 8).toInt();
            break;
          }
          hdr = "";
        }
      }
    }

    if (actualBytes <= 0 || actualBytes > (int)sizeof(chunkBuf)) {
      ok = false;
      break;
    }

    size_t got = gsmSerial.readBytes(chunkBuf, (size_t)actualBytes);
    sendAtWait(nullptr, "OK", 1500);

    if (got != (size_t)actualBytes) {
      ok = false;
      break;
    }

    if (isOtaFirmware) {
      Update.write(chunkBuf, got);
      totalRead += got;
      uint8_t pct = (uint8_t)((totalRead * 100) / (size_t)totalLen);
      if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
        sysState.ota_progress = pct;
        snprintf(sysState.ota_status_text, sizeof(sysState.ota_status_text),
                 "4G OTA: %u / %u KB", (unsigned)(totalRead / 1024), (unsigned)(totalLen / 1024));
        xSemaphoreGive(stateMutex);
      }
    } else {
      if (spiBusMutex != NULL && xSemaphoreTake(spiBusMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        sdFile.write(chunkBuf, got);
        xSemaphoreGive(spiBusMutex);
      }
      totalRead += got;
    }
    vTaskDelay(pdMS_TO_TICKS(2));
  }

  char closeCmd[32];
  snprintf(closeCmd, sizeof(closeCmd), "AT+QFCLOSE=%d", fileHandle);
  sendAtWait(closeCmd, "OK", 1500);
  sendAtWait("AT+QFDEL=\"UFS:dl_tmp.bin\"", "OK", 1500);

  if (!isOtaFirmware) {
    if (spiBusMutex != NULL && xSemaphoreTake(spiBusMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
      sdFile.close();
      xSemaphoreGive(spiBusMutex);
    }
  }
  return ok && (totalRead == (size_t)totalLen);
}

static void performWifiScan() {
  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
    sysState.wifi_scan_in_progress = true;
    xSemaphoreGive(stateMutex);
  }

  int n = WiFi.scanNetworks(false, false);
  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(20)) == pdTRUE) {
    uint8_t count = (n > 0) ? (uint8_t)min(n, 12) : 0;
    sysState.wifi_found_count = count;
    for (uint8_t i = 0; i < count; i++) {
      strncpy(sysState.wifi_list[i].ssid, WiFi.SSID(i).c_str(), 32);
      sysState.wifi_list[i].ssid[32] = '\0';
      sysState.wifi_list[i].rssi = WiFi.RSSI(i);
      sysState.wifi_list[i].is_open = (WiFi.encryptionType(i) == WIFI_AUTH_OPEN);
    }
    sysState.wifi_scan_in_progress = false;
    sysState.wifi_scan_ready = true;
    xSemaphoreGive(stateMutex);
  }
  WiFi.scanDelete();
}

static void connectToWifi(const char *ssid, const char *pass, bool saveToNvs) {
  if (!ssid || ssid[0] == '\0') return;

  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
    sysState.wifi_connecting = true;
    strncpy(sysState.wifi_ssid, ssid, sizeof(sysState.wifi_ssid) - 1);
    xSemaphoreGive(stateMutex);
  }

  WiFi.mode(WIFI_STA);
  if (pass && pass[0] != '\0') {
    WiFi.begin(ssid, pass);
  } else {
    WiFi.begin(ssid);
  }

  uint32_t t0 = millis();
  while (WiFi.status() != WL_CONNECTED && (millis() - t0 < 10000)) {
    vTaskDelay(pdMS_TO_TICKS(250));
  }

  bool ok = (WiFi.status() == WL_CONNECTED);
  if (ok && saveToNvs) {
    wifiPrefs.begin("wifi_cfg", false);
    wifiPrefs.putString("ssid", ssid);
    wifiPrefs.putString("pass", pass ? pass : "");
    wifiPrefs.end();
  }

  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
    sysState.wifi_connecting = false;
    sysState.wifi_connected = ok;
    if (!ok) sysState.wifi_ssid[0] = '\0';
    xSemaphoreGive(stateMutex);
  }
}

static void pollEg800qSignal() {
  static uint32_t lastPoll = 0;
  if (millis() - lastPoll < 10000) return;
  lastPoll = millis();

  String resp;
  if (sendAtWait("AT+CSQ", "+CSQ:", 500, &resp)) {
    int p = resp.indexOf("+CSQ:");
    int rssi = resp.substring(p + 5).toInt();
    uint8_t bars = 0;
    if (rssi >= 2 && rssi <= 31) {
      if (rssi >= 20) bars = 4;
      else if (rssi >= 15) bars = 3;
      else if (rssi >= 10) bars = 2;
      else bars = 1;
    }
    if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
      sysState.gsm_bars = bars;
      sysState.gsm_registered = (bars > 0);
      xSemaphoreGive(stateMutex);
    }
  }
}

static void serviceAudioAssetDownloads() {
  bool wifiUp = (WiFi.status() == WL_CONNECTED);
  if (!wifiUp && !sysState.gsm_registered) return;

  char targetAudioPath[64] = {0};
  if (!popNextMissingAudioFile(targetAudioPath, sizeof(targetAudioPath))) return;

  String url = String(API_BASE_URL) + "/audio" + String(targetAudioPath);

  if (wifiUp) {
    HTTPClient http;
    http.begin(url);
    if (http.GET() == HTTP_CODE_OK) {
      WiFiClient *stream = http.getStreamPtr();
      File outFile;
      bool opened = false;

      if (spiBusMutex != NULL && xSemaphoreTake(spiBusMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
        outFile = SD.open(targetAudioPath, FILE_WRITE);
        opened = (bool)outFile;
        xSemaphoreGive(spiBusMutex);
      }

      if (opened) {
        uint8_t netBuf[512];
        while (http.connected()) {
          size_t avail = stream->available();
          if (avail) {
            int r = stream->readBytes(netBuf, min(avail, sizeof(netBuf)));
            if (r > 0 && spiBusMutex != NULL && xSemaphoreTake(spiBusMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
              outFile.write(netBuf, r);
              xSemaphoreGive(spiBusMutex);
            }
          } else {
            vTaskDelay(pdMS_TO_TICKS(5));
          }
        }
        if (spiBusMutex != NULL && xSemaphoreTake(spiBusMutex, pdMS_TO_TICKS(100)) == pdTRUE) {
          outFile.close();
          xSemaphoreGive(spiBusMutex);
        }
        Serial.printf("[NET-WIFI] Downloaded audio asset: %s\n", targetAudioPath);
      }
    }
    http.end();
  } else {
    if (eg800qHttpDownloadBinary(url.c_str(), targetAudioPath, false)) {
      Serial.printf("[NET-4G] Downloaded audio asset: %s\n", targetAudioPath);
    }
  }
}

static void executeAuthorizedOtaUpdate(const char *binUrl) {
  bool wifiUp = (WiFi.status() == WL_CONNECTED);

  if (wifiUp) {
    HTTPClient http;
    http.begin(binUrl);
    int httpCode = http.GET();
    int contentLength = http.getSize();

    if (httpCode != HTTP_CODE_OK || contentLength <= 0 || !Update.begin((size_t)contentLength)) {
      if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
        strcpy(sysState.ota_status_text, "Wi-Fi OTA start failed");
        xSemaphoreGive(stateMutex);
      }
      vTaskDelay(pdMS_TO_TICKS(2000));
      if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
        sysState.ota_active = false;
        xSemaphoreGive(stateMutex);
      }
      http.end();
      return;
    }

    WiFiClient *client = http.getStreamPtr();
    uint8_t buff[1024];
    size_t written = 0;

    while (http.connected() && written < (size_t)contentLength) {
      size_t avail = client->available();
      if (avail) {
        int c = client->readBytes(buff, min(avail, sizeof(buff)));
        if (c > 0) {
          Update.write(buff, c);
          written += c;
          uint8_t pct = (uint8_t)((written * 100) / (size_t)contentLength);
          if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
            sysState.ota_progress = pct;
            snprintf(sysState.ota_status_text, sizeof(sysState.ota_status_text),
                     "Wi-Fi OTA: %u / %u KB", (unsigned)(written / 1024), (unsigned)(contentLength / 1024));
            xSemaphoreGive(stateMutex);
          }
        }
      }
      vTaskDelay(pdMS_TO_TICKS(2));
    }
    http.end();
  } else {
    if (!eg800qHttpDownloadBinary(binUrl, nullptr, true)) {
      if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
        strcpy(sysState.ota_status_text, "4G OTA download failed");
        xSemaphoreGive(stateMutex);
      }
      vTaskDelay(pdMS_TO_TICKS(2500));
      if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
        sysState.ota_active = false;
        xSemaphoreGive(stateMutex);
      }
      return;
    }
  }

  if (Update.end(true)) {
    if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
      sysState.ota_progress = 100;
      strcpy(sysState.ota_status_text, "Update complete! Rebooting...");
      xSemaphoreGive(stateMutex);
    }
    vTaskDelay(pdMS_TO_TICKS(1500));
    ESP.restart();
  } else {
    if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
      strcpy(sysState.ota_status_text, "OTA flash verification failed!");
      xSemaphoreGive(stateMutex);
    }
    vTaskDelay(pdMS_TO_TICKS(2500));
    if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
      sysState.ota_active = false;
      xSemaphoreGive(stateMutex);
    }
  }
}

static void handleOtaWorkflow() {
  bool authApproved = false;
  bool authCancelled = false;
  char urlCopy[160] = {0};

  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
    authApproved = sysState.ota_auth_approved;
    authCancelled = sysState.ota_auth_cancelled;
    strncpy(urlCopy, sysState.pending_ota_url, sizeof(urlCopy) - 1);
    if (authApproved) sysState.ota_auth_approved = false;
    if (authCancelled) sysState.ota_auth_cancelled = false;
    xSemaphoreGive(stateMutex);
  }

  if (authCancelled) {
    Serial.println("[OTA] Firmware update cancelled by operator.");
    return;
  }

  if (authApproved && urlCopy[0] != '\0') {
    executeAuthorizedOtaUpdate(urlCopy);
    return;
  }

  if (otaCheckRequested) {
    otaCheckRequested = false;
    bool wifiUp = (WiFi.status() == WL_CONNECTED);
    if (!wifiUp && !sysState.gsm_registered) return;

    String payload;
    bool gotManifest = false;

    if (wifiUp) {
      HTTPClient http;
      http.begin(OTA_MANIFEST_URL);
      if (http.GET() == HTTP_CODE_OK) {
        payload = http.getString();
        gotManifest = true;
      }
      http.end();
    } else {
      gotManifest = eg800qHttpGetToString(OTA_MANIFEST_URL, payload);
    }

    if (gotManifest) {
      int vIdx = payload.indexOf("\"version\":\"");
      int uIdx = payload.indexOf("\"url\":\"");
      if (vIdx >= 0 && uIdx >= 0) {
        String remoteVer = payload.substring(vIdx + 11, payload.indexOf("\"", vIdx + 11));
        String binUrl = payload.substring(uIdx + 7, payload.indexOf("\"", uIdx + 7));
        if (remoteVer != FW_VERSION && binUrl.length() > 8) {
          if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(15)) == pdTRUE) {
            strncpy(sysState.pending_ota_url, binUrl.c_str(), sizeof(sysState.pending_ota_url) - 1);
            sysState.ota_auth_required = true;
            sysState.ota_auth_approved = false;
            sysState.ota_auth_cancelled = false;
            xSemaphoreGive(stateMutex);
          }
        }
      }
    }
  }
}

void initGsmAndWifi() {
  gsmSerial.begin(115200, SERIAL_8N1, PIN_GSM_RX, PIN_GSM_TX);
  sendAtWait("ATE0", "OK", 1000);

  wifiPrefs.begin("wifi_cfg", true);
  String savedSsid = wifiPrefs.getString("ssid", "");
  String savedPass = wifiPrefs.getString("pass", "");
  wifiPrefs.end();

  if (savedSsid.length() > 0) {
    connectToWifi(savedSsid.c_str(), savedPass.c_str(), false);
  }
}

void serviceNetworkAndOta() {
  bool doScan = false;
  bool doConnect = false;
  bool wifiEnabled = true;
  char targetSsid[33] = {0};
  char targetPass[65] = {0};

  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
    wifiEnabled = sysState.wifi_enabled;
    if (sysState.wifi_scan_requested) {
      sysState.wifi_scan_requested = false;
      doScan = true;
    }
    if (sysState.wifi_connect_requested) {
      sysState.wifi_connect_requested = false;
      doConnect = true;
      strncpy(targetSsid, sysState.target_wifi_ssid, sizeof(targetSsid) - 1);
      strncpy(targetPass, sysState.target_wifi_pass, sizeof(targetPass) - 1);
    }
    sysState.wifi_connected = (WiFi.status() == WL_CONNECTED);
    xSemaphoreGive(stateMutex);
  }

  if (!wifiEnabled) {
    if (WiFi.getMode() != WIFI_OFF) {
      WiFi.disconnect(true);
      WiFi.mode(WIFI_OFF);
    }
  } else {
    if (doConnect) {
      connectToWifi(targetSsid, targetPass, true);
    }
    if (doScan) {
      performWifiScan();
    }
  }

  pollEg800qSignal();

  if (routeSyncRequested) {
    routeSyncRequested = false;
    String routePayload;
    bool synced = false;

    if (WiFi.status() == WL_CONNECTED) {
      HTTPClient http;
      http.begin(ROUTE_SYNC_URL);
      if (http.GET() == HTTP_CODE_OK) {
        routePayload = http.getString();
        synced = true;
      }
      http.end();
    } else if (sysState.gsm_registered) {
      synced = eg800qHttpGetToString(ROUTE_SYNC_URL, routePayload);
    }

    if (synced) {
      Serial.printf("[NET] Route schedule synchronized (%u bytes).\n", (unsigned)routePayload.length());
    }
  }

  serviceAudioAssetDownloads();
  handleOtaWorkflow();
}
