#include "battery_monitor.h"
#include <Wire.h>

#define MAX17048_ADDR       0x36
#define MAX17048_REG_VCELL  0x02
#define MAX17048_REG_SOC    0x04
#define MAX17048_REG_CRATE  0x16

static bool gaugePresent = false;

static uint16_t readGaugeReg16(uint8_t reg) {
  Wire1.beginTransmission(MAX17048_ADDR);
  Wire1.write(reg);
  if (Wire1.endTransmission(false) != 0) return 0xFFFF;
  if (Wire1.requestFrom((uint8_t)MAX17048_ADDR, (uint8_t)2) != 2) return 0xFFFF;
  uint16_t hi = Wire1.read();
  uint16_t lo = Wire1.read();
  return (hi << 8) | lo;
}

void initBatteryMonitor() {
  Wire1.begin(PIN_BAT_SDA, PIN_BAT_SCL, 100000);
  Wire1.beginTransmission(MAX17048_ADDR);
  gaugePresent = (Wire1.endTransmission() == 0);
  Serial.printf("[BAT] MAX17048 on Wire1: %s\n", gaugePresent ? "OK" : "Not Found");
}

void serviceBatteryMonitor() {
  static uint32_t lastRead = 0;
  if (millis() - lastRead < 2000) return;
  lastRead = millis();

  if (!gaugePresent) return;

  uint16_t rawV = readGaugeReg16(MAX17048_REG_VCELL);
  uint16_t rawSoc = readGaugeReg16(MAX17048_REG_SOC);
  uint16_t rawCrate = readGaugeReg16(MAX17048_REG_CRATE);

  if (rawV == 0xFFFF || rawSoc == 0xFFFF) return;

  // MAX17048 VCELL = 78.125 uV/LSB; SOC = 1/256 % per LSB
  float voltage = (rawV * 78.125f) / 1000000.0f;
  int soc = rawSoc >> 8;
  if (soc > 100) soc = 100;
  if (soc < 0) soc = 0;

  // Signed CRATE: positive indicates charging current
  int16_t signedCrate = (int16_t)rawCrate;
  bool charging = (signedCrate > 25);

  if (xSemaphoreTake(stateMutex, pdMS_TO_TICKS(10)) == pdTRUE) {
    sysState.battery_voltage = voltage;
    sysState.battery_percent = (uint8_t)soc;
    sysState.is_charging = charging;
    xSemaphoreGive(stateMutex);
  }
}
